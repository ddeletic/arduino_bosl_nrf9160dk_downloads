/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_INCLUDE_DT_BINDINGS_PINCTRL_NRF_PINCTRL_H_
#define ZEPHYR_INCLUDE_DT_BINDINGS_PINCTRL_NRF_PINCTRL_H_

/*
 * The whole nRF pin configuration information is encoded in a 32-bit bitfield
 * organized as follows:
 *
 * - 31..16: Pin function.
 * - 15:     Reserved.
 * - 14:     Pin inversion mode.
 * - 13:     Pin low power mode.
 * - 12..9:  Pin output drive configuration.
 * - 8..7:   Pin pull configuration.
 * - 6..0:   Pin number (combination of port and pin).
 */

/**
 * @name nRF pin configuration bit field positions and masks.
 * @{
 */

/** Position of the function field. */
#define NRF_FUN_POS 16U
/** Mask for the function field. */
#define NRF_FUN_MSK 0xFFFFU
/** Position of the invert field. */
#define NRF_INVERT_POS 14U
/** Mask for the invert field. */
#define NRF_INVERT_MSK 0x1U
/** Position of the low power field. */
#define NRF_LP_POS 13U
/** Mask for the low power field. */
#define NRF_LP_MSK 0x1U
/** Position of the drive configuration field. */
#define NRF_DRIVE_POS 9U
/** Mask for the drive configuration field. */
#define NRF_DRIVE_MSK 0xFU
/** Position of the pull configuration field. */
#define NRF_PULL_POS 7U
/** Mask for the pull configuration field. */
#define NRF_PULL_MSK 0x3U
/** Position of the pin field. */
#define NRF_PIN_POS 0U
/** Mask for the pin field. */
#define NRF_PIN_MSK 0x7FU

/** @} */

/**
 * @name nRF pinctrl pin functions.
 * @{
 */

/** UART TX */
#define NRF_FUN_UART_TX 0U
/** UART RX */
#define NRF_FUN_UART_RX 1U
/** UART RTS */
#define NRF_FUN_UART_RTS 2U
/** UART CTS */
#define NRF_FUN_UART_CTS 3U
/** SPI master SCK */
#define NRF_FUN_SPIM_SCK 4U
/** SPI master MOSI */
#define NRF_FUN_SPIM_MOSI 5U
/** SPI master MISO */
#define NRF_FUN_SPIM_MISO 6U
/** SPI slave SCK */
#define NRF_FUN_SPIS_SCK 7U
/** SPI slave MOSI */
#define NRF_FUN_SPIS_MOSI 8U
/** SPI slave MISO */
#define NRF_FUN_SPIS_MISO 9U
/** SPI slave CSN */
#define NRF_FUN_SPIS_CSN 10U
/** TWI master SCL */
#define NRF_FUN_TWIM_SCL 11U
/** TWI master SDA */
#define NRF_FUN_TWIM_SDA 12U
/** I2S SCK in master mode */
#define NRF_FUN_I2S_SCK_M 13U
/** I2S SCK in slave mode */
#define NRF_FUN_I2S_SCK_S 14U
/** I2S LRCK in master mode */
#define NRF_FUN_I2S_LRCK_M 15U
/** I2S LRCK in slave mode */
#define NRF_FUN_I2S_LRCK_S 16U
/** I2S SDIN */
#define NRF_FUN_I2S_SDIN 17U
/** I2S SDOUT */
#define NRF_FUN_I2S_SDOUT 18U
/** I2S MCK */
#define NRF_FUN_I2S_MCK 19U
/** PDM CLK */
#define NRF_FUN_PDM_CLK 20U
/** PDM DIN */
#define NRF_FUN_PDM_DIN 21U
/** PWM OUT0 */
#define NRF_FUN_PWM_OUT0 22U
/** PWM OUT1 */
#define NRF_FUN_PWM_OUT1 23U
/** PWM OUT2 */
#define NRF_FUN_PWM_OUT2 24U
/** PWM OUT3 */
#define NRF_FUN_PWM_OUT3 25U
/** QDEC A */
#define NRF_FUN_QDEC_A 26U
/** QDEC B */
#define NRF_FUN_QDEC_B 27U
/** QDEC LED */
#define NRF_FUN_QDEC_LED 28U
/** QSPI SCK */
#define NRF_FUN_QSPI_SCK 29U
/** QSPI CSN */
#define NRF_FUN_QSPI_CSN 30U
/** QSPI IO0 */
#define NRF_FUN_QSPI_IO0 31U
/** QSPI IO1 */
#define NRF_FUN_QSPI_IO1 32U
/** QSPI IO2 */
#define NRF_FUN_QSPI_IO2 33U
/** QSPI IO3 */
#define NRF_FUN_QSPI_IO3 34U

/** @} */

/**
 * @name nRF pinctrl output drive.
 * @note Values match nrf_gpio_pin_drive_t constants.
 * @{
 */

/** Standard '0', standard '1'. */
#define NRF_DRIVE_S0S1 0U
/** High drive '0', standard '1'. */
#define NRF_DRIVE_H0S1 1U
/** Standard '0', high drive '1'. */
#define NRF_DRIVE_S0H1 2U
/** High drive '0', high drive '1'. */
#define NRF_DRIVE_H0H1 3U
/** Disconnect '0' standard '1'. */
#define NRF_DRIVE_D0S1 4U
/** Disconnect '0', high drive '1'. */
#define NRF_DRIVE_D0H1 5U
/** Standard '0', disconnect '1'. */
#define NRF_DRIVE_S0D1 6U
/** High drive '0', disconnect '1'. */
#define NRF_DRIVE_H0D1 7U
/** Extra high drive '0', extra high drive '1'. */
#define NRF_DRIVE_E0E1 11U

/** @} */

/**
 * @name nRF pinctrl pull-up/down.
 * @note Values match nrf_gpio_pin_pull_t constants.
 * @{
 */

/** Pull-up disabled. */
#define NRF_PULL_NONE 0U
/** Pull-down enabled. */
#define NRF_PULL_DOWN 1U
/** Pull-up enabled. */
#define NRF_PULL_UP 3U

/** @} */

/**
 * @name nRF pinctrl low power mode.
 * @{
 */

/** Input. */
#define NRF_LP_DISABLE 0U
/** Output. */
#define NRF_LP_ENABLE 1U

/** @} */

/**
 * @name nRF pinctrl helpers to indicate disconnected pins.
 * @{
 */

/** Indicates that a pin is disconnected */
#define NRF_PIN_DISCONNECTED NRF_PIN_MSK

/** @} */

/**
 * @brief Utility macro to build nRF psels property entry.
 *
 * @param fun Pin function configuration (see NRF_FUNC_{name} macros).
 * @param port Port (0 or 1).
 * @param pin Pin (0..31).
 */
#define NRF_PSEL(fun, port, pin)						       \
	((((((port) * 32U) + (pin)) & NRF_PIN_MSK) << NRF_PIN_POS) |		       \
	 ((NRF_FUN_ ## fun & NRF_FUN_MSK) << NRF_FUN_POS))

/**
 * @brief Utility macro to build nRF psels property entry when a pin is disconnected.
 *
 * This can be useful in situations where code running before Zephyr, e.g. a bootloader
 * configures pins that later needs to be disconnected.
 *
 * @param fun Pin function configuration (see NRF_FUN_{name} macros).
 */
#define NRF_PSEL_DISCONNECTED(fun)						       \
	(NRF_PIN_DISCONNECTED |							       \
	 ((NRF_FUN_ ## fun & NRF_FUN_MSK) << NRF_FUN_POS))

#endif /* ZEPHYR_INCLUDE_DT_BINDINGS_PINCTRL_NRF_PINCTRL_H_ */
