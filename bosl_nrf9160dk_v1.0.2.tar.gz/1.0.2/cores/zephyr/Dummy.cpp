void dummy (void)
{}
