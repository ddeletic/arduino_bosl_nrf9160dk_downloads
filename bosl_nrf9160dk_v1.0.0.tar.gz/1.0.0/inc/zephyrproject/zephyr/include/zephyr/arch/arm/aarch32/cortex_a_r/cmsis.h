/*
 * Copyright (c) 2023 Nordic Semiconductor ASA
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_ARCH_ARM_AARCH32_CORTEX_A_R_CMSIS_H_
#define ZEPHYR_ARCH_ARM_AARCH32_CORTEX_A_R_CMSIS_H_

#include <cmsis_core.h>

#warning This header is deprecated, please include <cmsis_core.h>

#endif /* ZEPHYR_ARCH_ARM_AARCH32_CORTEX_A_R_CMSIS_H_ */
